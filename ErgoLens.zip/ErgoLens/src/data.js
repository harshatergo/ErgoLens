

const SampleData = 
    [ 
        {
        key : 0,
        page_no :"1",
        header : "medical_attestation",
        data : [
            {
                key : "",
                fieldName : "patient_name",
                value : "HAENE STEFAN"
            },
            {
                key : "",
                fieldName : "patient_status",
                value : "50%"
            },
            {
                key : "",
                fieldName : "issue_date",
                value : "2002-03-27"
            },
            {
                key : "",
                fieldName : "service_type",
                value : "ATTEST WIN VERGOEDBARE FARMACEUTISCHE VERSTREKRINGEN IN HET KADER VANEEN BUKORENE VERZEKERING"
            },
            {
                key : "",
                fieldName : "establishment_number",
                value : "312302"
            },
            {
                key : "",
                fieldName : "prescriber_name",
                value : "THOONE"
            },
            {
                key : "",
                fieldName : "prescriber_id",
                value : "14876628762"
            },
            {
                key : "",
                fieldName : "establishment_number",
                value : "312302"
            },
            {
                key : "",
                fieldName : "prescriber_name",
                value : "THOONE"
            },
            {
                key : "",
                fieldName : "prescriber_id",
                value : "14876628762"
            },
            {
                key : "",
                fieldName : "establishment_number",
                value : "312302"
            },
            {
                key : "",
                fieldName : "prescriber_name",
                value : "THOONE"
            },
            {
                key : "",
                fieldName : "prescriber_id",
                value : "14876628762"
            },
            {
                key : "",
                fieldName : "establishment_number",
                value : "312302"
            },
            {
                key : "",
                fieldName : "prescriber_name",
                value : "THOONE"
            },
            {
                key : "",
                fieldName : "prescriber_id",
                value : "14876628762"
            },
            {
                key : "",
                fieldName : "patient_name",
                value : "HAENE STEFAN"
            },
            {
                key : "",
                fieldName : "patient_status",
                value : "50%"
            },
            {
                key : "",
                fieldName : "issue_date",
                value : "2002-03-27"
            },
            {
                key : "",
                fieldName : "service_type",
                value : "ATTEST WIN VERGOEDBARE FARMACEUTISCHE VERSTREKRINGEN IN HET KADER VANEEN BUKORENE VERZEKERING"
            },
            {
                key : "",
                fieldName : "establishment_number",
                value : "312302"
            },
            {
                key : "",
                fieldName : "prescriber_name",
                value : "THOONE"
            },
            {
                key : "",
                fieldName : "prescriber_id",
                value : "14876628762"
            },
            {
                key : "",
                fieldName : "establishment_number",
                value : "312302"
            },
            {
                key : "",
                fieldName : "prescriber_name",
                value : "THOONE"
            },
            {
                key : "",
                fieldName : "prescriber_id",
                value : "14876628762"
            },
            {
                key : "",
                fieldName : "establishment_number",
                value : "312302"
            },
            {
                key : "",
                fieldName : "prescriber_name",
                value : "THOONE"
            },
            {
                key : "",
                fieldName : "prescriber_id",
                value : "14876628762"
            },
            {
                key : "",
                fieldName : "establishment_number",
                value : "312302"
            },
            {
                key : "",
                fieldName : "prescriber_name",
                value : "THOONE"
            },
            {
                key : "",
                fieldName : "prescriber_id",
                value : "14876628762"
            }
        ]
        }

    ]


export default SampleData;