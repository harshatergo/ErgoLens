import React from 'react'
import SampleData from '../data'
import './css/home.css'
const DataBox = () => {
    return (
        <div className="data_box home_box home_box_right" style = {{height:"90vh", overflowY:"scroll"}}>
          {SampleData.map((page) => (
                <div key={page.key}>
                    <h3 style ={{padding : "1em",marginBottom:"1.5em",marginTop:"5px",position:"sticky", backgroundColor:"#e0eaea", color : "black", borderRadius:"5px"}}>{page.header}</h3>
                    <div>
                        {page.data.map((item, index) => (
                            <div key={index} style = {{backgroundColor:"white", color :"black", fontSize:".8em", display:"flex",borderRadius:"5px", justifyContent:"space-between", padding : ".5em ", margin :"1em 0px"}}>
                               <span style ={{textAlign:"left", minWidth:"30%"}}> <strong>{item.fieldName}:</strong></span> <span style ={{textAlign:"right", minWidth:"70%"}}>{item.value}</span>
                            </div>
                        ))}
                    </div>
                </div>
            ))}
        </div>
    )
}

export default DataBox