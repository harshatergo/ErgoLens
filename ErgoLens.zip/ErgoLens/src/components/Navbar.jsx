import React from 'react'
import '../components/css/navbar.css'

const Navbar = () => {
  return (
    <div className="nav_container">
        <div className="nav_left">
            <img src="..\src\assets\round-arrow.png" height = "18px" width = "18px"/> inbox
        </div>
        <div className="nav_mid">
            <span style ={{fontWeight:"bold", fontSize:"1.2em"}}>Bill Copy.pdf</span> (1 documents)
        </div>
        <div className="nav_right">
            <div className="nav_right_item1 nav_right_item">
            First document
            </div>
            <div className="nav_right_item2 nav_right_item">
            Last document 
            </div>
        </div>
    </div>
  )
}

export default Navbar