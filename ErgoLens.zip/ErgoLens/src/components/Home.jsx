import React from 'react'
import './css/home.css'
import DocumentBox from './DocumentBox'
import DataBox from './DataBox'
const Home = () => {
    return (
        <div className="home_container" >
           <DocumentBox/>
            <DataBox/>
        </div>
    )
}

export default Home